<?php
/**
 * Main Template of GreenTea WordPress Theme
 *
 * @package   GreenTea
 * @version   1.1.0
 * @date      2014.12.16
 * @author    FzPying&Unknown <fzpying@gmail.com>
 * @site      FzPyingBlog <www.fzpying.com>
 * @copyright Copyright (c) 2014-2016, FzPying&Unknown
 * @license   http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link      http://www.fzpying.com/
**/

?>
<form method="get" class="searchform themeform" action="<?php echo home_url('/'); ?>">
	<div>
		<input type="text" class="search" name="s" onblur="if(this.value=='')this.value='<?php _e('Search..','tinection'); ?>';" onfocus="if(this.value=='<?php _e('Search..','tinection'); ?>')this.value='';" value="<?php _e('Search..','tinection'); ?>" maxlength="20" required="required" />
	</div>
</form>