<?php
/**
 * Single Product Template of GreenTea WordPress Theme
 *
 * @package   GreenTea
 * @version   1.1.8
 * @date      2016.6.5
 * @author    FzPying&Unknown <fzpying@gmail.com>
 * @site      FzPyingBlog <www.fzpying.com>
 * @copyright Copyright (c) 2014-2016, FzPying&Unknown
 * @license   http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link      http://www.fzpying.com/
**/

?>
<?php get_header(); ?>
<!-- Main Wrap -->
<div id="main-wrap">
	<div id="single-blog-wrap" class="container shop">
		<div class="area">
		<!-- Content -->
		<div class="product-content">
			<div class="breadcrumb">
				<a href="<?php echo get_bloginfo('url').'/store'; ?>"><?php _e('商店','tinection'); ?></a>&nbsp;