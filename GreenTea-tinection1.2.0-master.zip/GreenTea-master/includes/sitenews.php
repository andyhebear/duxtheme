<?php
/**
 * Includes of GreenTea WordPress Theme
 *
 * @package   GreenTea
 * @version   1.1.8
 * @date      2016.6.1
 * @author    FzPying&Unknown <fzpying@gmail.com>
 * @site      FzPyingBlog <www.fzpying.com>
 * @copyright Copyright (c) 2014-2016, FzPying&Unknown
 * @license   http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link      http://www.fzpying.com/
**/

?>
<?php $sitenews=ot_get_option('sitenews');if (!empty($sitenews)) { ?>
<div class="contextual bg-sitenews">
	<i class="fa fa-volume-up" style=""></i>
	<div id="news-scroll-zone">
		<div class="news-scroll-list">
			<?php $sitenews = explode(PHP_EOL,$sitenews);foreach ($sitenews as $sitenew) {echo '<li class="sitenews-list">'.$sitenew.'</li>';} ?>
		</div>
	</div>
	<span class="infobg-close" style="color:#aaa;"><i class="fa fa-close"></i></span>
</div>
<?php } ?>